<?php

$db_host = "localhost";
$db_base = "casadalimpeza";
$db_user = "root";
$db_password = "";

$title_site = "Casa da  Limpeza | Panel Admin";


$protocol = isset($_SERVER['HTTPS']) ? (($_SERVER['HTTPS'] && $_SERVER['HTTPS'] != "off") ? "https" : "http") :'http';
DEFINE("BASE_URL", $protocol . "://" . $_SERVER['HTTP_HOST'].'/casadalimpeza/');
DEFINE("PATH_IMG", $protocol . "://" . $_SERVER['HTTP_HOST'].'/casadalimpeza/uploads/');
DEFINE("BASE_PATH", $_SERVER['DOCUMENT_ROOT'].'/casadalimpeza/');
