!function(n){var e="mmenu";n[e].i18n({Menu:"Menü"})}(jQuery);
!function(e){var n="mmenu";e[n].i18n({"Close menu":"Menü schließen","Close submenu":"Untermenü schließen","Open submenu":"Untermenü öffnen","Toggle submenu":"Untermenü wechseln"})}(jQuery);
!function(e){var n="mmenu";e[n].i18n({Search:"Suche","No results found.":"Keine Ergebnisse gefunden.",cancel:"beenden"})}(jQuery);