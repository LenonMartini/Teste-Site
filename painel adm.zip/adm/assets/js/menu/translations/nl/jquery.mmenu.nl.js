!function(n){var u="mmenu";n[u].i18n({Menu:"Menu"})}(jQuery);
!function(e){var u="mmenu";e[u].i18n({"Close menu":"Menu sluiten","Close submenu":"Submenu sluiten","Open submenu":"Submenu openen","Toggle submenu":"Submenu wisselen"})}(jQuery);
!function(e){var n="mmenu";e[n].i18n({Search:"Zoeken","No results found.":"Geen resultaten gevonden.",cancel:"annuleren"})}(jQuery);